package hu.pe.erman;
import android.app.*;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.util.ArrayList;
import hu.pe.erman.Coneccao.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.AuthResult;
import android.net.NetworkInfo;
import android.content.Context;
import android.net.ConnectivityManager;

public class Cadastro extends Activity
{
	//private FirebaseAuth mAuth;
	
	ArrayList<String> al;
	EditText email,pass;
	
	ListView lll;
	
	Button cadastrar;
	TextView erro;
	private FirebaseAuth auth;

    private EditText pass2;

	
	@Override
	protected void onCreate(Bundle savedInstanceState)
    {
		
		
		/////////////
		super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastro);

		cadastrar=(Button)findViewById(R.id.cadastrar);
		
		
		email=(EditText)findViewById(R.id.emailnovo);
		email.getBackground().setAlpha(50);
		pass=(EditText)findViewById(R.id.passnovo);
        pass2=(EditText)findViewById(R.id.passnovo);
		
		
		
		cadastrar.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				
		String emaily=email.getText().toString().trim();
		String senha=pass.getText().toString().trim();
         if(!isNetworkAvailable())
        criarUser(emaily,senha);
				
			}

            
            
            
            
			private void criarUser(String emaily, String senha)
			{
				// TODO: Implement this method
				auth.createUserWithEmailAndPassword(emaily,senha)
					.addOnCompleteListener(Cadastro.this, new OnCompleteListener<AuthResult>(){

						@Override
						public void onComplete(Task<AuthResult> task)
						{
							// TODO: Implement this method
							if(task.isSuccessful()){
								alerta("Cadastrado com sucesso");
								Intent k=new Intent(Cadastro.this,MainActivity.class);
						startActivity(k);

							}else{
								alerta("Erro ao cadastrar");
							}
						}
						
		
	});

			}
		});
		
		
		
		
		
	}

	@Override
	protected void onStart()
	{
		
		
		super.onStart();
		auth=conexao.firebaseAuth();
	}
	
	
	
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
	
	
	private void alerta(String txt){
		Toast.makeText(getApplicationContext(), txt, Toast.LENGTH_LONG).show();
	}
    
    
    
    private boolean isNetworkAvailable()
    {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=cm.getActiveNetworkInfo();

        if(networkInfo !=null && networkInfo.isConnected()){
            return true;
        }
        return false;
    }
}
