package hu.pe.erman.Modelo;

public class Actividade
{
    private String id;
    private String nomeActividade;
    private String dataActividade;
    private String idActividadeFeita;
    private boolean visto;
    private String usuarioAuthID;

    public void setUsuarioAuthID(String usuarioAuthID)
    {
        this.usuarioAuthID = usuarioAuthID;
    }

    public String getUsuarioAuthID()
    {
        return usuarioAuthID;
    }

    public void setVisto(boolean visto)
    {
        this.visto = visto;
    }

    public boolean isVisto()
    {
        return visto;
    }


    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public void setNomeActividade(String nomeActividade)
    {
        this.nomeActividade = nomeActividade;
    }

    public String getNomeActividade()
    {
        return nomeActividade;
    }

    public void setDataActividade(String dataActividade)
    {
        this.dataActividade = dataActividade;
    }

    public String getDataActividade()
    {
        return dataActividade;
    }

    public void setIdActividadeFeita(String idActividadeFeita)
    {
        this.idActividadeFeita = idActividadeFeita;
    }

    public String getIdActividadeFeita()
    {
        return idActividadeFeita;
    }

    @Override
    public String toString()
    {
        // TODO: Implement this method
        return getNomeActividade()+"\n   "+getDataActividade();
    }
    
    
    
    
    }
