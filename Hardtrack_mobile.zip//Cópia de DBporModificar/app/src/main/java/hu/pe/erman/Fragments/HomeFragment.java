package hu.pe.erman.Fragments;

import android.app.*;
import android.os.*;
import android.view.*;
import hu.pe.erman.*;
import android.widget.*;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;



public class HomeFragment extends Fragment
{
Button registar;
EditText email;
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		
		//registar=(Button) view.fi
		
		//return inflater.inflate(R.layout.fragment_home, container, false);
		View view=inflater.inflate(R.layout.fragment_home, container, false);
        
        //ANUNCIOS
        MobileAds.initialize(getActivity(), "ca-app-pub-9016085290328620~1226986182");
        AdView adView=(AdView)view.findViewById(R.id.adViewHome);
        AdRequest adRequest=new AdRequest.Builder().build();
        adView.loadAd(adRequest);
        
		
		//registar=(Button)view.findViewById(R.id.cadastrarfragment);
		//email=(EditText)view.findViewById(R.id.emailnovofragment);
		/*registar.setOnClickListener(
			new View.OnClickListener(){

				@Override
				public void onClick(View v)
				{
					// TODO: Implement this me
					email.setText("helo fragment");
					alerta("hello","welcome");
					
				}


			});*/
		
		
		return view;
	      
	}
	
	private void alerta(String titulo, String texto)
	{
		// TODO: Implement this method
		AlertDialog.Builder ale=new AlertDialog.Builder(getActivity());
		ale.setCancelable(true);
		ale.setIcon(R.drawable.hardtrack);
		ale.setTitle(titulo);
		ale.setMessage(texto);
		ale.show();
	}
	
	
	
}
