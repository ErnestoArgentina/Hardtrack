package hu.pe.erman.Coneccao;
import com.google.firebase.FirebaseApp;
import android.content.*;
import java.util.*;
import hu.pe.erman.Modelo.*;
import hu.pe.erman.*;

public class InitFirebase
{

    public static ArrayList<Carro> arrayCarros=new ArrayList();
    
    public static ArrayList<Clientes> arrayClientes=new ArrayList();
    
    
    public static int jaIniciou=0;

    
    
    
    
    
    
}
