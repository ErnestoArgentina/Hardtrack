package hu.pe.erman.VisaoMind;
import android.content.*;
import android.graphics.drawable.*;
import android.os.*;
import android.support.v7.app.ActionBarActivity;
import android.view.*;
import android.widget.*;
import com.google.firebase.database.FirebaseDatabase;
import hu.pe.erman.Coneccao.*;
import java.util.*;
import android.support.design.widget.FloatingActionButton;
import android.graphics.Color;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import android.support.v7.app.AlertDialog;
import com.google.firebase.FirebaseApp;
import hu.pe.erman.Modelo.*;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import android.view.View.*;
import java.text.*;
import hu.pe.erman.*;


public class ListaFuncionarios extends ActionBarActivity implements OnClickListener
{
    ListView lll;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private List<Funcionario> listFuncionario=new ArrayList<Funcionario>();
    private ArrayAdapter<Funcionario> arrayAdapterFuncionario;
    EditText nome,email,morada,telefone,bi;
    EditText biArquivo,biDataEmissao,BiDataValidade,salario,dadosBancarios;
    private FirebaseAuth mAuth;
    private Funcionario FuncionarioSelecionado;
    private Actividade act;
    private FloatingActionButton fab;

    private FirebaseUser user;
    private Button btDataEmissao,btDataValidade;
    private String sexo="null";
    private String cargo="null";
    private DatePicker datePicker;
    private Date dataActual =new Date();
    private SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    private String data;

    private EditText password;










    @Override
    public void onClick(View view)
    {
        // TODO: Implement this method
        boolean checked=((RadioButton) view).isChecked();

        switch (view.getId())
        {
                /////////Sexo
            case R.id.rbMasculinoFuncionario:
                if (checked) 
                    sexo = "Masculino";
                break;
            case R.id.rbFemininoFuncionario:
                if (checked)
                    sexo = "Feminino";
                break;
            case R.id.rbAdministradorFuncionario:
                if (checked) 
                    cargo = "Administrador";
                break;
            case R.id.rbVendedorFuncionario:
                if (checked)
                    cargo = "Vendedor";
                break;
        }
    }











    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();

        /*if(id==R.id.action_RegistarFuncionario){
         Intent i=new Intent(ListaFuncionarios.this,RegistarFuncionario.class);
         startActivity(i);
         }*/

        if (id == R.id.action_exit)
        {
            finish();
        }
        if (id == R.id.action_SairDaConta)
        {
            mAuth.getInstance().signOut();
            Intent i=new Intent(ListaFuncionarios.this, Login.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }



    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_funcionario);
        inicializarvariaveis();
        inicializarFirebase();
        InitFirebase.jaIniciou += 1;
        accao_listview();

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();



        TabHost th=(TabHost)findViewById(R.id.tthhFuncionarios);
        th.setup();
        th.getBottom();

        TabHost.TabSpec sp=th.newTabSpec("");
        sp.setContent(R.id.registoFuncionario);
        sp.setIndicator("📝Registar");
        th.setBackground(new ColorDrawable(Color.parseColor("#007fff")));
        th.addTab(sp);

        sp = th.newTabSpec("");
        sp.setContent(R.id.ListViewFuncionario);
        sp.setIndicator("📃Listar");
        th.addTab(sp);




        ArrayAdapter<CharSequence> spSexoAdapter=ArrayAdapter.createFromResource(this,
                                                                                 R.array.sexoArray, android.R.layout.simple_spinner_item);

        //spSexoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        //spSexo.setAdapter(spSexoAdapter);





        fab.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    Funcionario funcionario=new Funcionario();
                    funcionario.setBi(bi.getText().toString());
                    funcionario.setNome(nome.getText().toString());
                    funcionario.setEmail(email.getText().toString());
                    funcionario.setMorada(morada.getText().toString());
                    funcionario.setContacto((telefone.getText().toString()));
                    funcionario.setUsuarioAuthID(user.getUid() + "");
                    funcionario.setId(UUID.randomUUID().toString());
                    funcionario.setBiArquivoIdentificacao(biArquivo.getText().toString().trim());
                    funcionario.setBiDataEmissao(biDataEmissao.getText().toString().trim());
                    funcionario.setBiDataValidade(BiDataValidade.getText().toString().trim());
                    funcionario.setCargo(cargo);
                    funcionario.setSexo(sexo);
                    funcionario.setDadosBancarios((dadosBancarios.getText().toString().trim()));
                    funcionario.setEstadoDeletado("on");
                    funcionario.setPassword(password.getText().toString().trim());
                    if(salario.getText().toString().trim().length()==0)
                    funcionario.setSalario(0.0); else
                    funcionario.setSalario(Double.parseDouble(salario.getText().toString().trim()));


                    if (bi.getText().toString().equals("") || nome.getText().toString().equals("") || telefone.getText().toString().equals("") || morada.getText().toString().trim().equals(""))
                    {
                        AlertDialog.Builder ale=new AlertDialog.Builder(ListaFuncionarios.this);
                        ale.setCancelable(true);
                        ale.setIcon(R.drawable.ic_alerta_preto);
                        ale.setTitle("ERRO");
                        ale.setMessage("Preencha todos os campos");
                        ale.show();
                    }
                    else
                    {
                        if (email.getText().toString().trim().contains("@") && email.getText().toString().trim().contains("."))
                        {
                            if (nome.getText().toString().trim().contains(" "))
                            {
                                databaseReference.child("Funcionario").child(funcionario.getId()).setValue(funcionario);
                                alerta("Gravado com Sucesso");   
                                registarActividade("Adicionou ",funcionario.getId(),funcionario.getNome());
                                limparCampos();
                            }
                            else alerta("Introduza um nome completo");
                        }
                        else alerta("Introduza um Email Valido");
                    }
                }});


        eventoDatabase();
        btDataEmissao.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){

                    alertDatePicker(biDataEmissao);
                }
            });
        btDataValidade.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){

                    alertDatePicker(BiDataValidade);
                }
            });
    }

    private void eventoDatabase()
    {
        //Query query=databaseReference.child("Funcionarios").child("usuarioAuthID").equalTo(mAuth.getCurrentUser().getUid().toString());

        databaseReference.child("Funcionario").addValueEventListener(new ValueEventListener(){

                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    listFuncionario.clear();
                    for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
                    {
                        Funcionario funcionario=objSnapshot.getValue(Funcionario.class);
                        if (funcionario.getUsuarioAuthID().equalsIgnoreCase(user.getUid() + "") && funcionario.getEstadoDeletado().equalsIgnoreCase("on"))
                            listFuncionario.add(funcionario);

                    }
                    arrayAdapterFuncionario = new ArrayAdapter<Funcionario>(ListaFuncionarios.this, R.layout.list_item, listFuncionario);

                    lll.setAdapter(arrayAdapterFuncionario);

                }

                @Override
                public void onCancelled(DatabaseError p1)
                {
                    // TODO: Implement this method
                    alerta(p1.toString());
                }
            });
    }





    private void inicializarvariaveis()
    {
        lll = (ListView)findViewById(R.id.listaFuncionario);
        fab = (FloatingActionButton) findViewById(R.id.fabSaveFuncionario);
        nome = (EditText) findViewById(R.id.nomeFuncionario);
        bi = (EditText) findViewById(R.id.biFuncionario);
        telefone = (EditText) findViewById(R.id.telefoneFuncionario);
        morada = (EditText) findViewById(R.id.moradaFuncionario);
        email = (EditText) findViewById(R.id.emailFuncionario);
        biArquivo = (EditText) findViewById(R.id.biArquivoFuncionario);
        biDataEmissao = (EditText) findViewById(R.id.biDataEmissaoEditTextFuncionario);
        BiDataValidade = (EditText) findViewById(R.id.biDataValidadeEditTextFuncionario);
        btDataValidade = (Button) findViewById(R.id.biDataValidadeFuncionario);
        btDataEmissao = (Button) findViewById(R.id.biDataEmissaoFuncionario);
        dadosBancarios=(EditText) findViewById(R.id.dadosBancariosFuncionario);
        salario = (EditText) findViewById(R.id.salarioFuncionario);
        password = (EditText) findViewById(R.id.passwordFuncionario);
        //spSexo=(Spinner)findViewById(R.id.lista_FuncionarioSpinner);
    }







    private void inicializarFirebase()
    {
        // alerta(" "+InitFirebase.jaIniciou);
        // TODO: Implement this method
        FirebaseApp.initializeApp(ListaFuncionarios.this);
        firebaseDatabase = FirebaseDatabase.getInstance();
        if (InitFirebase.jaIniciou == 0)
            firebaseDatabase.setPersistenceEnabled(true);
        databaseReference = firebaseDatabase.getReference();

    }





    private void limparCampos()
    {
        bi.setText("");
        nome.setText("");
        email.setText("");
        morada.setText("");
        telefone.setText("");
        salario.setText("");
        biDataEmissao.setText("");
        BiDataValidade.setText("");
        biArquivo.setText("");
    }





    private void alerta(String p0)
    {
        AlertDialog.Builder ale=new AlertDialog.Builder(ListaFuncionarios.this);
        ale.setCancelable(true);
        ale.setIcon(R.drawable.ic_alerta_branco);
        ale.setTitle("Alert");
        ale.setMessage(p0);
        ale.show();
    }





    public void alertEditFuncionario()
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(ListaFuncionarios.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_edit_clientes, null);
        final EditText mEmail=(EditText)mView.findViewById(R.id.DialogEmailCliente);
        final EditText mBI=(EditText)mView.findViewById(R.id.DialogBICliente);
        final EditText mNome=(EditText)mView.findViewById(R.id.DialogNomeCliente);
        final EditText mTelefone=(EditText)mView.findViewById(R.id.DialogTelefoneCliente);
        final EditText mMorada=(EditText)mView.findViewById(R.id.DialogMoradaCliente);
        mEmail.setText(FuncionarioSelecionado.getEmail());
        mBI.setText(FuncionarioSelecionado.getBi());
        mNome.setText(FuncionarioSelecionado.getNome());
        mTelefone.setText(FuncionarioSelecionado.getContacto());
        mMorada.setText(FuncionarioSelecionado.getMorada());

        Button DialogButtonEliminar=(Button) mView.findViewById(R.id.DialogButtonEliminar);

        DialogButtonEliminar.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    FuncionarioSelecionado.delete();
                    databaseReference.child("Funcionario").child(FuncionarioSelecionado.getId()).setValue(FuncionarioSelecionado);
                    alerta("Eliminado com sucesso");
                    registarActividade("Eliminou os dados do Funcionario ",FuncionarioSelecionado.getId(),FuncionarioSelecionado.getNome());


                }
            });
        Button DialogButtonEditar=(Button) mView.findViewById(R.id.DialogButtonSalvar);

        DialogButtonEditar.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    FuncionarioSelecionado.setNome(mNome.getText().toString().trim());
                    FuncionarioSelecionado.setBi(mBI.getText().toString().trim());
                    FuncionarioSelecionado.setContacto(mTelefone.getText().toString().trim());
                    FuncionarioSelecionado.setEmail(mEmail.getText().toString().trim());
                    FuncionarioSelecionado.setMorada(mMorada.getText().toString().trim());
                    databaseReference.child("Funcionario").child(FuncionarioSelecionado.getId()).setValue(FuncionarioSelecionado);
                    alerta("Editado com sucesso");
                    registarActividade("Actualizou os dados do Funcionario ",FuncionarioSelecionado.getId(),FuncionarioSelecionado.getNome());

                }
            });
        mBuilder.setView(mView);
        AlertDialog dialog=mBuilder.create();
        dialog.show();

    }







    void accao_listview()
    {
        lll.setOnItemClickListener(new AdapterView.OnItemClickListener(){

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    // TODO: Implement this method
                    FuncionarioSelecionado = (Funcionario)parent.getItemAtPosition(position);
                    alertEditFuncionario();
                }
            });
    }












    public void alertDatePicker(final EditText e)
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(ListaFuncionarios.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_date_picker, null);



        FloatingActionButton DialogDatePickerButtonOk=(FloatingActionButton) mView.findViewById(R.id.datePickerButton);
        datePicker = (DatePicker)mView.findViewById(R.id.datePicker);

        DialogDatePickerButtonOk.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {


                    //dataObtida= minhaData();
                    // setarData(dataObtida);
                    e.setText(minhaData());

                }

                private void setarData(String dataObtida)
                {
                    // TODO: Implement this method
                    e.setText(dataObtida);
                }
                private String minhaData()
                {
                    StringBuilder myCat=new StringBuilder();

                    myCat.append(datePicker.getDayOfMonth() + "/");
                    myCat.append((datePicker.getMonth() + 1) + "/");
                    myCat.append(datePicker.getYear());

                    return myCat.toString();
                }


            });

        mBuilder.setView(mView);
        AlertDialog dialog=mBuilder.create();
        dialog.show();
        //FecharAlert(dialog);



    }







    private void FecharAlert(AlertDialog dialog)
    {
        // TODO: Implement this method
        dialog.dismiss();
    }






    public void registarActividade(String actividade, String id, String nomeFuncionario){
        data=sdf.format(dataActual);
        act=new Actividade();
        act.setNomeActividade(actividade+" "+nomeFuncionario+" na lista de Funcionarios");
        act.setId(UUID.randomUUID().toString());
        act.setVisto(false);
        act.setIdActividadeFeita(id);
        act.setDataActividade(data);
        act.setUsuarioAuthID(user.getUid().toString());
        databaseReference.child("Actividade").child(act.getId()).setValue(act);
    }







}
