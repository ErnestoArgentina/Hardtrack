package hu.pe.erman.Modelo;

public abstract class Pessoa
{
    private String nome,bi,morada,id,sexo,contacto;
    private String biDataEmissao;
    private String biDataValidade;
    private String biArquivoIdentificacao;
    private String Email;
    private String usuarioAuthID;
    private String estadoDeletado;

    Pessoa()
    {}

    public void setEstadoDeletado(String estadoDeletado)
    {
        this.estadoDeletado = estadoDeletado;
    }

    public String getEstadoDeletado()
    {
        return estadoDeletado;
    }

    public void setUsuarioAuthID(String usuarioAuthID)
    {
        this.usuarioAuthID = usuarioAuthID;
    }

    public String getUsuarioAuthID()
    {
        return usuarioAuthID;
    }

    public void setBiDataEmissao(String biDataEmissao)
    {
        this.biDataEmissao = biDataEmissao;
    }

    public String getBiDataEmissao()
    {
        return biDataEmissao;
    }

    public void setBiDataValidade(String biDataValidade)
    {
        this.biDataValidade = biDataValidade;
    }

    public String getBiDataValidade()
    {
        return biDataValidade;
    }

    public void setBiArquivoIdentificacao(String biArquivoIdentificacao)
    {
        this.biArquivoIdentificacao = biArquivoIdentificacao;
    }

    public String getBiArquivoIdentificacao()
    {
        return biArquivoIdentificacao;
    }

    public void setEmail(String email)
    {
        Email = email;
    }

    public String getEmail()
    {
        return Email;
    };

    public void setNome(String nome)
    {
        this.nome = nome;
    }

    public String getNome()
    {
        return nome;
    }

    public void setBi(String bi)
    {
        this.bi = bi;
    }

    public String getBi()
    {
        return bi;
    }

    public void setMorada(String morada)
    {
        this.morada = morada;
    }

    public String getMorada()
    {
        return morada;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public void setSexo(String sexo)
    {
        this.sexo = sexo;
    }

    public String getSexo()
    {
        return sexo;
    }

    public void setContacto(String contacto)
    {
        this.contacto = contacto;
    }

    public String getContacto()
    {
        return contacto;
    }
    
    public void delete(){
        this.estadoDeletado="off";
    }
    }
