package hu.pe.erman.Coneccao;

import com.google.firebase.auth.*;
import org.apache.http.auth.*;

public class conexao
{
	private static FirebaseAuth firebaseAuth;
	private static FirebaseAuth.AuthStateListener authStateListener;
	private static FirebaseUser firebaseuser;
	
	
	private conexao(){
		
	}
	
	public static FirebaseAuth firebaseAuth(){
		if(firebaseAuth==null){
			inicializarFirebaseAuth();
		}
		return firebaseAuth;
	}
	
 private static void inicializarFirebaseAuth(){
	 
	 firebaseAuth=FirebaseAuth.getInstance();
	 authStateListener = new FirebaseAuth.AuthStateListener(){

		 @Override
		 public void onAuthStateChanged(FirebaseAuth p1)
		 {
			FirebaseUser user=firebaseAuth.getCurrentUser();
			if(user !=null){
				firebaseuser=user;
			}
		 }
	 };
	firebaseAuth.addAuthStateListener(authStateListener);
	
 }
 
 
 public static FirebaseUser getFirebaseUser(){
	 return firebaseuser;
 }
 
 
 
 public static void logOut(){
	 firebaseAuth.signOut();
	 
 }
 
 
 
 
 
 
 
}