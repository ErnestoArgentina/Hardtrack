package hu.pe.erman;



import android.content.Intent;
import android.net.*;
import android.os.*;
import android.support.v4.widget.DrawerLayout;
//import android.support.v4.widget.*;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.*;
import android.widget.EditText;
import com.google.firebase.auth.*;
import hu.pe.erman.*;
import hu.pe.erman.VisaoMind.*;

import android.app.ActionBar;
import android.app.AlertDialog;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.ActionBarDrawerToggle;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Notification;
import android.widget.Button;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.support.design.widget.NavigationView;
import hu.pe.erman.Fragments.*;
import android.app.*;
import com.google.firebase.auth.FirebaseAuth;
import hu.pe.erman.Coneccao.*;
import android.content.Context;



public class MainActivity extends AppCompatActivity
{
	private FirebaseAuth mAuth;
	DrawerLayout drawerLayout;
	//TextView navigationHeaderText;
	ActionBarDrawerToggle actionBarDrawerToggle;
	Toolbar toolBar;
	FragmentTransaction ft;
	NavigationView nv;
	Button registar;
    TextView textEmailUser;
    //Views
  //  View mViewError=getLayoutInflater().inflate(R.layout.dialog_error,null);
    
    //AlertBuilders
    //AlertDialog.Builder errorBuilder;
    
    //Dialogs
   // AlertDialog dialogError;

    
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.menu_main,menu);
		return super.onCreateOptionsMenu(menu);
	}
	


	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int id=item.getItemId();
		
		if(id==R.id.action_exit){
			finish();
		}
		return super.onOptionsItemSelected(item);
	}
	//////////////////////////////
	////////NOTIFICATION////////////
	////////////////////////////////
	public void sendNotification(View view){

		NotificationCompat.Builder mBuilder=new NotificationCompat.Builder(this).setSmallIcon(R.drawable.erman).setContentTitle("Minha notificacao").setContentText("Hello eord");

		NotificationManager mNotificationManager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
//NotificationManager.notify().
		mNotificationManager.notify(001,mBuilder.build());

	}
	
	/////////////////////////////////
	/////////////////////////////////
	
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
		//////////////
		 /////////////
		 //inicializarFirebase();
		super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		toolBar=(Toolbar)findViewById(R.id.toolBar);
		setSupportActionBar(toolBar);
        
		
		drawerLayout=(DrawerLayout)findViewById(R.id.drawerLayout);
		
		actionBarDrawerToggle=new ActionBarDrawerToggle(this,drawerLayout,toolBar,R.string.drawer_open,R.string.drawer_close);
		
		drawerLayout.setDrawerListener(actionBarDrawerToggle);
		
		ft=getFragmentManager().beginTransaction();
		ft.add(R.id.Frame_container, new HomeFragment());
		ft.commit();
		getSupportActionBar().setTitle("");
		
		
		nv=(NavigationView)findViewById(R.id.nav_view);

		nv.setNavigationItemSelectedListener(
			new NavigationView.OnNavigationItemSelectedListener(){

				@Override
				public boolean onNavigationItemSelected(MenuItem p1)
				{
					switch(p1.getItemId()){
						case R.id.home:
							ft=getFragmentManager().beginTransaction();
							ft.replace(R.id.Frame_container, new HomeFragment());
							ft.commit();
							getSupportActionBar().setTitle("");
							p1.setChecked(true);
							drawerLayout.closeDrawers();
							break;
						case R.id.clientes:
							/*ft=getFragmentManager().beginTransaction();
							ft.replace(R.id.Frame_container, new ClientesFragment());
							ft.commit();
							getSupportActionBar().setTitle("Clientes");
							p1.setChecked(true); */
                            Intent k=new Intent(MainActivity.this,ListaClientes.class);
							startActivity(k);
							drawerLayout.closeDrawers();
							break;
						case R.id.carros:
							 k=new Intent(MainActivity.this,ListaCarros.class);
							startActivity(k);
							p1.setChecked(false);
							drawerLayout.closeDrawers();
							break; 
						case R.id.vender: alertLogin();
							
							break; 
                        case R.id.acerca: alerta("HARDTRACK","V 1.0");
                            break;
                        
                        case R.id.definicoes: alertLogin();

							break; 
                           
                        case R.id.Notificacoes: 
                            ft=getFragmentManager().beginTransaction();
                            ft.replace(R.id.Frame_container, new ActividadesFragment());
                            ft.commit();
                            getSupportActionBar().setTitle("Actividades");
                            p1.setChecked(true);
                            drawerLayout.closeDrawers();
							break;
                        case R.id.funcionarios:
                            k=new Intent(MainActivity.this,ListaFuncionarios.class);
                            startActivity(k);
                            p1.setChecked(false);
                            drawerLayout.closeDrawers();
							break; 

						 
					}
					return false;
				}
			}
		);
		
        
		
	//////////Autenticacao firebase
		mAuth=FirebaseAuth.getInstance();
		FirebaseUser user=mAuth.getCurrentUser();
		if(user!=null){
Toast.makeText(getApplicationContext(),"Bem vindo de volta "+user.getEmail()+"!",Toast.LENGTH_LONG).show();
		}else{
			Intent intent=new Intent(this,Login.class);
			startActivity(intent);
			finish();
		}
		
      
        
        
        
   
/////notificacao
					NotificationCompat.Builder mBuilder=new NotificationCompat.Builder(MainActivity.this).setSmallIcon(R.drawable.hardtrack).setContentTitle("HARDTRACK").setContentText(" ");
					//Intent intent=new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com/"));
					Intent intent=new Intent(MainActivity.this,MainActivity.class);
					PendingIntent pendingIntent=PendingIntent.getActivity(MainActivity.this,0,intent,0);
					NotificationManager mNotificationManager=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
					mBuilder.setContentIntent(pendingIntent);
					mBuilder.setPriority(Notification.PRIORITY_MAX);
					mNotificationManager.notify(001,mBuilder.build());
	
			
	}

	
	
	
	
	@Override
	protected void onStart()
	{
		//pb.setVisibility(View.INVISIBLE);
		// TODO: Implement this method
		super.onStart();
        if(InitFirebase.jaIniciou==0)
		if(!isNetworkAvailable())
		alerta("Aviso", "Não há conecção à internet");
        //alertError("Não há conecção à internet");
	}
	
	
	
	

	private boolean isNetworkAvailable()
	{
	    ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo networkInfo=cm.getActiveNetworkInfo();
		
		if(networkInfo !=null && networkInfo.isConnected()){
			return true;
		}
		return false;
	}

	
	
	
	
	
	
	private void alerta(String titulo, String texto)
	{
		// TODO: Implement this method
		AlertDialog.Builder ale=new AlertDialog.Builder(this);
		ale.setCancelable(true);
		ale.setIcon(R.drawable.ic_alerta_preto);
		ale.setTitle(titulo);
		ale.setMessage(texto);
		ale.show();
	}

	
	
	
	
	
	@Override
	protected void onPostCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onPostCreate(savedInstanceState);
		actionBarDrawerToggle.syncState();
	}
	
	
	
	
	
	
	
	
    
    
    
	
    public void alertLogin()
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(MainActivity.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_login,null);
        final EditText mEmail=(EditText)mView.findViewById(R.id.etEmail);
        final EditText mPassword=(EditText)mView.findViewById(R.id.etPassword);
        Button mLogin=(Button) mView.findViewById(R.id.buttonLogin);

        mLogin.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    // TODO: Implement this method
                    if(!mEmail.getText().toString().isEmpty() && !mPassword.getText().toString().isEmpty()){
                        Toast.makeText(MainActivity.this,"sucess",Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(MainActivity.this,"sucess",Toast.LENGTH_SHORT).show();
                }
            });
        mBuilder.setView(mView);
        AlertDialog dialog=mBuilder.create();
        dialog.show();

    }
    
	
	
	
    
    
    public void alertEditCliente()
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(MainActivity.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_edit_clientes,null);
        //final EditText mEmail=(EditText)mView.findViewById(R.id.etEmail);
        //final EditText mPassword=(EditText)mView.findViewById(R.id.etPassword);
       /* Button mLogin=(Button) mView.findViewById(R.id.buttonLogin);

        mLogin.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    /*TODO: Implement this method
                    if(!mEmail.getText().toString().isEmpty() && !mPassword.getText().toString().isEmpty()){
                        Toast.makeText(MainActivity.this,"sucess",Toast.LENGTH_SHORT).show();
                    }
                    else
                        Toast.makeText(MainActivity.this,"sucess",Toast.LENGTH_SHORT).show(); 
                }
            });*/
        mBuilder.setView(mView);
        AlertDialog dialog=mBuilder.create();
        dialog.show();

    }
	
	
	
	
	
//	class CustomAdapter extends BaseAdapter
//	{
//
//		@Override
//		public int getCount()
//		{
//			// TODO: Implement this method
//			return 0;
//		}
//
//		@Override
//		public Object getItem(int p1)
//		{
//			// TODO: Implement this method
//			return null;
//		}
//
//		@Override
//		public long getItemId(int p1)
//		{
//			// TODO: Implement this method
//			return 0;
//		}
//
//		@Override
//		public View getView(int i, View view, ViewGroup p3)
//		{
//			view=getLayoutInflater().inflate(R.layout.customlayout_clientes,null);
//			ImageView imageView=(ImageView)view.findViewById(R.id.customImage);
//			TextView nome_cliente=(TextView)view.findViewById(R.id.customNome);
//			TextView telefone_cliente=(TextView)view.findViewById(R.id.customTelefone);
//			
//			imageView.setImageResource(R.drawable.erman);
//			nome_cliente.setText("nome aqui");
//			telefone_cliente.setText("telefone aqui");
//			return view;
//		}
//		
//		
//	}
    
    
    /*
    public void alertError(String s)
    {
        // TODO: Implement this method
        errorBuilder= new AlertDialog.Builder(MainActivity.this);
        
        //final EditText mEmail=(EditText)mView.findViewById(R.id.etEmail);
        //final EditText mPassword=(EditText)mView.findViewById(R.id.etPassword);
         Button btOkError=(Button) mViewError.findViewById(R.id.dialog_errorButton);
        TextView tvDialogError=(TextView)mViewError.findViewById(R.id.dialog_errorTextView);
        tvDialogError.setText(s);

         btOkError.setOnClickListener(new View.OnClickListener(){

         @Override
         public void onClick(View view)
         {
         dialogError.dismiss();
       
         }});
        errorBuilder.setView(mViewError);
        dialogError=errorBuilder.create();
        dialogError.show();

    } */
	
		
    
    
    
}
