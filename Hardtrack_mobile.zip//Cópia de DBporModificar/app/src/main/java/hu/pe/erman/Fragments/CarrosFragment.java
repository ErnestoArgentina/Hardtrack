package hu.pe.erman.Fragments;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.*;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;
import hu.pe.erman.*;
import hu.pe.erman.VisaoMind.*;
import java.util.*;

import hu.pe.erman.R;
import hu.pe.erman.Coneccao.*;



public class CarrosFragment extends Fragment
{
	TabHost th;
	View view;
	ListView lll;
	private Button registar;
	FirebaseDatabase firebaseDatabase;
	DatabaseReference databaseReference;

	private List<Clientes> listClientes=new ArrayList<Clientes>();
	private ArrayAdapter<Clientes> arrayAdapterClientes;
	private EditText marca,modelo,codModelo,chassi,numSerie,preco,anoFabrico;
	private FirebaseAuth auth;
	private Spinner spCaixa,spCombustivel,spCor,spAssentos,spTipo;
	private RadioButton manual,automatico,gasolina,diesel;

	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		
		inicializarFirebase();
        InitFirebase.jaIniciou+=1;
		view=inflater.inflate(R.layout.fragment_carros, container, false);
		// TODO: Implement this method
		tabhost();
		inicializarvariaveis();
		
		
		eventoDatabase();
		//return inflater.inflate(R.layout.fragment_carros, container, false);
		
		
     return view;
	}
	
	
	
	
	
	
	

	private void tabhost()
	{
		th=(TabHost)view.findViewById(R.id.tthhCarrosFragment);
		th.setup();
		// TODO: Implement this method
		TabHost.TabSpec sp=th.newTabSpec("");
		sp.setContent(R.id.registoCarrosFragment);
		sp.setIndicator("Registar");
		th.setBackground(new ColorDrawable(Color.parseColor("#0000dd")));
		th.addTab(sp);

		sp = th.newTabSpec("");
		sp.setContent(R.id.ListViewCarrosFragment);
		sp.setIndicator("Lista");
		th.addTab(sp);
	}
	
	
	
	
	
	
	private void eventoDatabase()
	{
		databaseReference.child("Clientes").addValueEventListener(new ValueEventListener(){

				@Override
				public void onDataChange(DataSnapshot dataSnapshot)
				{
					lll = (ListView)view.findViewById(R.id.listaCarroFragment);
					listClientes.clear();
					for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
					{
						Clientes c=objSnapshot.getValue(Clientes.class);
						listClientes.add(c);
						
					}
					arrayAdapterClientes = new ArrayAdapter<Clientes>(getActivity(), R.layout.list_item, listClientes);
					
					lll.setAdapter(arrayAdapterClientes);
					
				}

				@Override
				public void onCancelled(DatabaseError p1)
				{
					// TODO: Implement this method
				}
			});
	}
	
	
	
	
	
	
	
	private void inicializarFirebase()
	{
		// TODO: Implement this method
		FirebaseApp.initializeApp(getActivity());
		firebaseDatabase = FirebaseDatabase.getInstance();
        if(InitFirebase.jaIniciou==0)
		firebaseDatabase.setPersistenceEnabled(true);
		databaseReference = firebaseDatabase.getReference();
	}
	
	
	
	
	
	private void inicializarFirebase2()
	{
		// TODO: Implement this method
		//FirebaseApp.initializeApp(getActivity());
		//firebaseDatabase = FirebaseDatabase.getInstance();
		//firebaseDatabase.setPersistenceEnabled(true);
		//databaseReference = firebaseDatabase.getReference();
		
	}
	
	
	
	
	
	

	private void limparCampos()
	{
		marca.setText("");
		modelo.setText("");
		codModelo.setText("");
		preco.setText("");
		chassi.setText("");
	}
	
	
	
	
	
	
	
	
	private void inicializarvariaveis()
	{
		lll = (ListView)view.findViewById(R.id.listaCarroFragment);
		//registar = (Button) view.findViewById(R.id.registarCarro);
	}
	

	
	
	
	
	
	
	/*public void onRadioButtonClicked(View view){
		//boolean checked = false;
		boolean checked=((RadioButton) view).isChecked();
		//manual=(RadioButton) view.findViewById(R.id.rbManual);
		switch(view.getId()){
			case R.id.rbManual:
				 if(manual.isChecked()) alerta("Manual selecionado");
			   break;
			case R.id.rbAutomatico:
				if(checked) alerta("Automatico selecionado");
				break;
		}
		
		automatico=(RadioButton) view.findViewById(R.id.rbAutomatico);
		if(manual.isChecked())alerta("Manual");
		if(automatico.isChecked())alerta("Automatico");
		
	} */
	
	
	
	
	
	
	public void rbGasolinaClick(View view){
		gasolina=(RadioButton) view.findViewById(R.id.rbGasolina);
		if(gasolina.isChecked())alerta("Gasolina");
		
	}
	public void rbDieselClick(View view){
		diesel=(RadioButton) view.findViewById(R.id.rbDiesel);
		if(diesel.isChecked())alerta("Diesel");

	}
	
	
	
	
	
	
	

	private void alerta(String p0)
	{
		AlertDialog.Builder ale=new AlertDialog.Builder(getActivity());
		ale.setCancelable(true);
		ale.setIcon(R.drawable.hardtrack);
		ale.setTitle("Alert");
		ale.setMessage(p0);
		ale.show();
	}

	@Override
	public void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		alerta("Bem vindo");
	}
	
	
	
	
	
	
	
	
	
	
	
	public void onRadioButtonClicked(View view) {
		// Is the button now checked?
		boolean checked = ((RadioButton) view).isChecked();

		// Check which radio button was clicked
		switch(view.getId()) {
			case R.id.radio_pirates:
				if (checked) Toast.makeText(getActivity(),"hello pirate",Toast.LENGTH_LONG).show();
                // Pirates are the best
					break;
			case R.id.radio_ninjas:
				if (checked) Toast.makeText(getActivity(),"hello ninjas",Toast.LENGTH_LONG).show();
                // Ninjas rule
					break;
		}
	}
	
	
	
	
	
	
}
