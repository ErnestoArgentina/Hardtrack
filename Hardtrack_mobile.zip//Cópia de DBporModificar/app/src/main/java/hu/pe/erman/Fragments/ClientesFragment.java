package hu.pe.erman.Fragments;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.*;
import com.google.firebase.auth.*;
import com.google.firebase.database.*;
import hu.pe.erman.*;
import java.util.*;

import hu.pe.erman.R;
import android.widget.PopupMenu.*;
import hu.pe.erman.Coneccao.*;



public class ClientesFragment extends Fragment
{
	TabHost th;
	View view;
	Db_Helper ddd;
	ListView lll;
	private Button registar;
	FirebaseDatabase firebaseDatabase;
	DatabaseReference databaseReference;

	private List<Clientes> listClientes=new ArrayList<Clientes>();
	private ArrayAdapter<Clientes> arrayAdapterClientes;
	EditText nome,email,morada,telefone,bi;
	private FirebaseAuth auth;
	private Spinner spSexo;

	
	
	
	
	
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
        
		// TODO: Implement this method
		view=inflater.inflate(R.layout.fragment_clientes, container, false);
            tabhost();
			inicializarvariaveis();
			inicializarFirebase();
        InitFirebase.jaIniciou+=1;
		//eventoDatabase();
			
			registo();
		
		
		return view;
	}

	private void registo()
	{
		// TODO: Implement this method
		
		registar.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1){
					Clientes cl=new Clientes();
					cl.setBi(bi.getText().toString());
					cl.setNome(nome.getText().toString());
					cl.setEmail(email.getText().toString());
					cl.setMorada(morada.getText().toString());
					cl.setTelefone(telefone.getText().toString());


					if(bi.getText().toString().equals("") && nome.getText().toString().equals("") && telefone.getText().toString().equals("") ){
						AlertDialog.Builder ale=new AlertDialog.Builder(getActivity());
						ale.setCancelable(true);
						ale.setIcon(R.drawable.hardtrack);
						ale.setTitle("ERRO");
						ale.setMessage("Preencha todos os campos");
						ale.show();
					}   else{
						databaseReference.child("Clientes").child(cl.getBi()).setValue(cl);

						limparCampos();
					}
				}});


		
	}

	
	
	
	
	
	
	private void tabhost()
	{
		// TODO: Implement this method

		TabHost th=(TabHost)view.findViewById(R.id.tthhClientesFragment);
		th.setup();
		th.getBottom();

		TabHost.TabSpec sp=th.newTabSpec("");
		sp.setContent(R.id.registoClienteFragment);
		sp.setIndicator("Registar");
		th.setBackground(new ColorDrawable(Color.parseColor("#007dff")));
		th.addTab(sp);

		sp=th.newTabSpec("");
		sp.setContent(R.id.ListViewClienteFragment);
		sp.setIndicator("Lista");
		th.addTab(sp);
	}

	
	
	
	
	
	private void eventoDatabase()
	{
		databaseReference.child("Clientes").addValueEventListener(new ValueEventListener(){

				@Override
				public void onDataChange(DataSnapshot dataSnapshot)
				{
					listClientes.clear();
					for(DataSnapshot objSnapshot:dataSnapshot.getChildren()){
						Clientes c=objSnapshot.getValue(Clientes.class);
						listClientes.add(c);
						
					}
					arrayAdapterClientes=new ArrayAdapter<Clientes>(getActivity(),R.layout.list_item,listClientes);
					
					lll.setAdapter(arrayAdapterClientes);
					
				}

				@Override
				public void onCancelled(DatabaseError p1)
				{
					// TODO: Implement this method
				}
			});
	}

	private void inicializarvariaveis()
	{
		lll=(ListView)view.findViewById(R.id.listaClienteFragment);
		registar=(Button) view.findViewById(R.id.registarClienteTabf);
		nome=(EditText) view.findViewById(R.id.nomeClientef);
		bi=(EditText) view.findViewById(R.id.biClientef);
		telefone=(EditText) view.findViewById(R.id.telefoneClientef);
		morada=(EditText) view.findViewById(R.id.moradaClientef);
		email=(EditText) view.findViewById(R.id.emailClientef);
	
	}


	private void inicializarFirebase()
	{
		// TODO: Implement this method
		FirebaseApp.initializeApp(getActivity());
		firebaseDatabase=FirebaseDatabase.getInstance();
        if(InitFirebase.jaIniciou==0)
		firebaseDatabase.setPersistenceEnabled(true);
		databaseReference=firebaseDatabase.getReference();
	}

	private void limparCampos()
	{
		bi.setText("");
		nome.setText("");
		email.setText("");
		morada.setText("");
		telefone.setText("");
	}
	
	
	
	
	

}
