package hu.pe.erman.VisaoMind;

import android.content.*;
import android.graphics.Color;
import android.graphics.drawable.*;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AlertDialog;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.Menu;
import android.view.View;
import android.widget.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.connection.R;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.FirebaseNetworkException;
import com.google.firebase.FirebaseException;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.MobileAds;
import hu.pe.erman.*;
import java.util.*;
import android.widget.CalendarView.*;
import android.support.v7.widget.Toolbar;
import hu.pe.erman.Modelo.*;
import hu.pe.erman.Coneccao.*;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdRequest;
import android.support.design.widget.FloatingActionButton;
import com.google.firebase.auth.FirebaseUser;

public class ListaCarros extends ActionBarActivity implements OnClickListener
{

	

	Db_Helper ddd;
	ListView lll,lll2;
	private Button registar;
	FirebaseDatabase firebaseDatabase;
	DatabaseReference databaseReference;
    private int comecou=0;

    private List<Carro> listCarros=new ArrayList<Carro>();
    private ArrayAdapter<Carro> arrayAdapterCarros;
	private List<Carro> listCarros2=new ArrayList<Carro>();
	private ArrayAdapter<Carro> arrayAdapterCarros2;
	private EditText marca,modelo,codModelo,chassi,numSerie,preco,anoFabrico;
	private FirebaseAuth auth;
	private Spinner spCor,spTipo;
	private String stmarca,stmodelo,stcodModelo,stchassi,
	stnumSerie,stanoFabrico,dataRegist,dataVenda,
	imgUrl,usuarioAuthId,
	stCaixa,stCombustivel,stCor,stAssentos,stTipo,stCilindrada;
	private double stpreco;
	private FirebaseAuth mAuth;
	FirebaseUser user;
	//Toolbar toolBar;
    private FloatingActionButton fab;



	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.menu_carro, menu);
		return super.onCreateOptionsMenu(menu);
	}



	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int id=item.getItemId();

		/*if (id == R.id.action_RegistarCliente)
		{
			Intent i=new Intent(ListaCarros.this, RegistarCliente.class);
			startActivity(i);
		}*/

		if (id == R.id.action_exit)
		{
			finish();
		}
		if (id == R.id.action_SairDaConta)
		{
	        auth.getInstance().signOut();
			Intent i=new Intent(ListaCarros.this, Login.class);
			startActivity(i);
		}
		return super.onOptionsItemSelected(item);
	}
	@Override
	protected void onCreate(Bundle savedInstanceState)
    {////actionBar////
		//ActionBar bar=getActionBar();
		//bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000aa")));
		////////////////
        MobileAds.initialize(ListaCarros.this, "ca-app-pub-9016085290328620~1226986182");
		super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_carros);
		
		//toolBar=(Toolbar)findViewById(R.id.toolBarListaCarros);
       //--     AdView adView=new AdView(this);
       //--      adView.setAdSize(AdSize.BANNER);
       //--     adView.setAdUnitId( "ca-app-pub-9016085290328620/5976677632");
        //para teste
       // adView.setAdUnitId( "ca-app-pub-3940256099942544/6300978111");
        
        AdView adView=(AdView)findViewById(R.id.adView);
        //adView.setAdSize(AdSize.BANNER);
        AdRequest adRequest=new AdRequest.Builder().build();
        //-- adView.setAdUnitId( "ca-app-pub-3940256099942544/6300978111"); //copia
        adView.loadAd(adRequest);
		
		
		//chamador
		inicializarvariaveis();
        
		inicializarFirebase();
        
        InitFirebase.jaIniciou+=1;
        


		TabHost th=(TabHost)findViewById(R.id.tthhCarros);
		th.setup();
		th.getBottom();

		TabHost.TabSpec sp=th.newTabSpec("");
		sp.setContent(R.id.registoCarros);
		sp.setIndicator("Registar");
		th.setBackground(new ColorDrawable(Color.parseColor("#007fff")));
		th.addTab(sp);

		sp = th.newTabSpec("");
		sp.setContent(R.id.ListViewCarros);
		sp.setIndicator("Disponiveis");
		th.addTab(sp);
        
        sp = th.newTabSpec("");
        sp.setContent(R.id.ListViewCarrosVendidos);
        sp.setIndicator("Vendidos");
		th.addTab(sp);


		mAuth=FirebaseAuth.getInstance();
		user=mAuth.getCurrentUser();
		usuarioAuthId=user.getUid()+"";
		
//////////////////////////////////////////////////////////////////////////
        stCaixa="";
        stCombustivel="";
        stCilindrada="";
//////////////////////////////////////////////////////////////////////////
		//////////////////////////////////////////////////////////////////////////

        eventoDatabaseCarros();
       // eventoDatabaseCarrosVendidos();
		fab.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
				{
                    inicializarStrings();
                    if (marca.getText().toString().trim().equals("") || modelo.getText().toString().trim().equals("") || chassi.getText().toString().trim().equals("") ||
                        preco.getText().toString().trim().equals("")|| stCombustivel.length()==0 || stCilindrada.length()==0 || stCaixa.length()==0)
                    {
                        AlertDialog.Builder ale=new AlertDialog.Builder(ListaCarros.this);
                        ale.setCancelable(true);
                        ale.setIcon(R.drawable.hardtrack);
                        ale.setTitle("ERRO");
                        ale.setMessage("Preencha todos os campos");
                        ale.show();
                    }
                    else
                    {
					gravar();
                    }
				}
			});
		
	}

	

    
    
    
    
    private void eventoDatabaseCarros()
    {
        databaseReference.child("Carro").addValueEventListener(new ValueEventListener(){

                

                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    listCarros.clear();
                    listCarros2.clear();
                    for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
                    {
                        Carro c=objSnapshot.getValue(Carro.class);
                        //para carros disponiveis
                        if(c.getUsuarioAuthID().equalsIgnoreCase(usuarioAuthId) && c.getEstadoDeletado().equalsIgnoreCase("on") && c.getEstadoCompra().equalsIgnoreCase("disponivel")  )
                        listCarros.add(c);
                        //para caros vendidos
                        if(c.getEstadoDeletado().equalsIgnoreCase("on") && !c.getEstadoCompra().equalsIgnoreCase("disponivel") && c.getUsuarioAuthID().equalsIgnoreCase(usuarioAuthId))
                            listCarros.add(c);
                     
                    }
                    //para carros disponiveis
                    arrayAdapterCarros = new ArrayAdapter<Carro>(ListaCarros.this, R.layout.list_item_big, listCarros);
                    lll.setAdapter(arrayAdapterCarros);
                   // para carros vendidos
                    arrayAdapterCarros2 = new ArrayAdapter<Carro>(ListaCarros.this, R.layout.list_item_big, listCarros2);
                    lll2.setAdapter(arrayAdapterCarros2);
                    
                
                }

                @Override
                public void onCancelled(DatabaseError p1)
                {
                    // TODO: Implement this method
                }
            });
	}
    
    
    
    
    
    
    private void eventoDatabaseCarrosVendidos()
    {
        databaseReference.child("Carro").addValueEventListener(new ValueEventListener(){



                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    listCarros2.clear();
                    for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
                    {
                        Carro c=objSnapshot.getValue(Carro.class);
                        if(c.getEstadoDeletado().equalsIgnoreCase("on") && !c.getEstadoCompra().equalsIgnoreCase("disponivel") && c.getUsuarioAuthID().equalsIgnoreCase(usuarioAuthId))
                            listCarros.add(c);

                    } //alerta(usuarioAuthId+"   "+ user.getUid());
                    arrayAdapterCarros2 = new ArrayAdapter<Carro>(ListaCarros.this, R.layout.list_item_big, listCarros2);

                    lll2.setAdapter(arrayAdapterCarros2);

                }

                @Override
                public void onCancelled(DatabaseError p1)
                {
                    // TODO: Implement this method
                }
            });
	}
    
    
    
    
    
    
	private void inicializarvariaveis()
	{
		lll = (ListView)findViewById(R.id.listaCarro);
        lll2 = (ListView)findViewById(R.id.listaCarroVendidos);
		fab= (FloatingActionButton) findViewById(R.id.fabSaveCarros);
		
		marca=(EditText) findViewById(R.id.marca);
		modelo=(EditText) findViewById(R.id.modelo);
		anoFabrico=(EditText) findViewById(R.id.anoFabrico);
		chassi=(EditText) findViewById(R.id.chassi);
		numSerie=(EditText) findViewById(R.id.serie);
		preco=(EditText) findViewById(R.id.preco);	
	}


    
    
    
    
	private void inicializarFirebase()
	{
		// TODO: Implement this method
		FirebaseApp.initializeApp(ListaCarros.this);
		firebaseDatabase = FirebaseDatabase.getInstance();
		if(InitFirebase.jaIniciou==0)
        firebaseDatabase.setPersistenceEnabled(true);
		databaseReference = firebaseDatabase.getReference();
	}
    
    
    
    
    

	private void limparCampos()
	{
		marca.setText("");
		modelo.setText("");
		//codModelo.setText("");
		preco.setText("");
		chassi.setText("");
        anoFabrico.setText("");
        numSerie.setText("");
	}

	
	
	
	
	
	@Override
	public void onClick(View view)
	{

		boolean checked=((RadioButton) view).isChecked();

		switch(view.getId()){
		/////////Caixa
			case R.id.rbManualLista:
				if(checked) //alerta("Manual selecionado: "+user.getEmail()+" com o id"+user.getUid());
				stCaixa="Manual";
				break;
			case R.id.rbAutomaticoLista:
				if(checked)// alerta("Automatico selecionado");
				stCaixa="Automático";
				break;
		////////Combustivel
			case R.id.rbDieselLista:
				if(checked) //alerta("Diesel: "+user.getEmail()+" com o id"+user.getUid());
				stCombustivel="Diesel";
				break;
			case R.id.rbGasolinaLista:
				if(checked) //alerta("Gasolina selecionado");
				stCombustivel="Gasolina";
				break;
            case R.id.rbGasLista:
                if(checked) //alerta("Gasolina selecionado");
                    stCombustivel="Gas";
				break;
            case R.id.rbEletricoLista:
                if(checked) //alerta("Gasolina selecionado");
                    stCombustivel="Eletrico";
				break;
		///////Cilindrada
			case R.id.rbC4Lista:
				if(checked) //alerta("4");
				stCilindrada="4";
				break;
			case R.id.rbC8Lista:
				if(checked)// alerta("8");
				stCilindrada="8";
				break;
			case R.id.rbC10Lista:
				if(checked)// alerta("10");
				stCombustivel="10";
				break;
			case R.id.rbC12Lista:
				if(checked)// alerta("12");
				stCombustivel="12";
				break;
		
		}

	}
	
	
	
	
	
	private void inicializarStrings()
	{
		// TODO: Implement this method
		stmarca=marca.getText().toString().trim();
		stmodelo=modelo.getText().toString().trim();
		stchassi=chassi.getText().toString().trim();
		stnumSerie=numSerie.getText().toString().trim();
		stanoFabrico=anoFabrico.getText().toString().trim();
        if(preco.getText().toString().trim().equalsIgnoreCase(""))
            stpreco=0.0; 
        else stpreco=Double.parseDouble(preco.getText().toString().trim());
		dataVenda="null";
		imgUrl="null";
		dataRegist="null";
		stCor="null";
		//usuarioAuthId=user.getUid();
		//combustivel
		//caixa
		//stcilindrada
		//estadoDeletado
		//estadoCompra
		//,stAssentos,stTipo
	}
	
	
	
	
	
	
	private void alerta(String p0)
	{
		AlertDialog.Builder ale=new AlertDialog.Builder(ListaCarros.this);
		ale.setCancelable(true);
		ale.setIcon(R.drawable.ic_alerta_branco);
		ale.setTitle("Alert");
		ale.setMessage(p0);
		ale.show();
	}

    
    
    
    
    
	@Override
	protected void onStart()
	{
		// TODO: Implement this method
		super.onStart();
       // comecou+=2;
		
		
	}

    @Override
    protected void onRestart()
    {
        // TODO: Implement this method
        super.onRestart();
        
    }

    @Override
    protected void onResume()
    {
        // TODO: Implement this method
        super.onResume();
        
    }
    
    
    

    
    
	private void gravar()
	{
		// TODO: Implement this method
		
		Carro c=new Carro();

		c.setCaixa(stCaixa);
		c.setChassi(stchassi);
		c.setCilindrada(stCilindrada);
		c.setCombustivel(stCombustivel);
		c.setAnoFabrico(stanoFabrico);
		c.setCor(stCor);
		c.setDataRegisto(dataRegist);
		c.setDataVenda(dataVenda);
		c.setEstadoCompra("disponivel");
		c.setEstadoDeletado("on");
		c.setImageUrl(imgUrl);
		c.setMarca(stmarca);
		c.setModelo(stmodelo);
        c.setVolante("Direito");
		c.setTipoCarro("Default");
		c.setPreco(stpreco);
		c.setUsuarioAuthID(usuarioAuthId);
		c.setSerie(stnumSerie);
        c.setId(UUID.randomUUID().toString());
        c.setFuncionarioID("sem");
        c.setClienteID("sem");

        
        


		
			databaseReference.child("Carro").child(c.getId()).setValue(c);

			limparCampos();
            alerta("Adicionado com sucesso");
		
	}
	
	

	
	
	
}
