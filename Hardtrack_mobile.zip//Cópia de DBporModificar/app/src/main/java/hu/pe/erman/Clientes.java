package hu.pe.erman;

public class Clientes
{
	private String nome,email, bi,telefone,morada;
    private String id;
public Clientes( ){};
	public Clientes(String nome, String email, String bi,String telefone,String morada)
	{
		this.nome = nome;
		this.email = email;
		this.bi = bi;
		this.telefone=telefone;
		this.morada = morada;
	}

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

	public void setNome(String nome)
	{
		this.nome = nome;
	}

	public String getNome()
	{
		return nome;
	}
public void setMorada(String morada)
	{
		this.morada = morada;
	}

	public String getMorada()
	{
		return morada;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getEmail()
	{
		return email;
	}

	public void setBi(String bi)
	{
		this.bi = bi;
	}

	public String getBi()
	{
		return bi;
	}

	public void setTelefone(String telefone)
	{
		this.telefone = telefone;
	}

	public String getTelefone()
	{
		return telefone;
	}

	@Override
	public String toString()
	{
		// TODO: Implement this method
		return nome+"\n  "+telefone;
	}

	

	}
