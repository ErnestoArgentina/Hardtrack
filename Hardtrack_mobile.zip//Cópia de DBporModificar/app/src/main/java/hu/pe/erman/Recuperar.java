package hu.pe.erman;

import android.app.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.firebase.auth.FirebaseAuth;
import java.util.*;
import hu.pe.erman.Coneccao.*;
import android.net.ConnectivityManager;
import android.content.Context;
import android.net.NetworkInfo;

public class Recuperar extends Activity
{
	//private FirebaseAuth mAuth;

	ArrayList<String> al;
	EditText email;
	Button mandar;
	private FirebaseAuth auth;

	@Override
	protected void onCreate(Bundle savedInstanceState)
    {
		
		super.onCreate(savedInstanceState);
        setContentView(R.layout.recuperar);

		mandar=(Button)findViewById(R.id.mandar);
		email=(EditText)findViewById(R.id.emailRecuperar);
		email.getBackground().setAlpha(50);



		mandar.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){

					String emaily=email.getText().toString().trim();
					
					resetPassword(emaily);

				}

				
				
			});





	}

	@Override
	protected void onStart()
	{


		super.onStart();
		auth=conexao.firebaseAuth();
	}



///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////


	private void alerta(String txt){
		Toast.makeText(getApplicationContext(), txt, Toast.LENGTH_LONG).show();
	}
	
	private void resetPassword(String emaily)
	{
		// TODO: Implement this method
        if(!isNetworkAvailable()){
		auth.sendPasswordResetEmail(emaily);
		alerta("sucess");}
        else alerta("verifique a sua ligacao de internet");
	}
    
    
    
    private boolean isNetworkAvailable()
    {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=cm.getActiveNetworkInfo();

        if(networkInfo !=null && networkInfo.isConnected()){
            return true;
        }
        return false;
    }
    
}
