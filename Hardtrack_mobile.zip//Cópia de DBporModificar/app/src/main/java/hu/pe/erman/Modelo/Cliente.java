package hu.pe.erman.Modelo;

public class Cliente extends Pessoa
{
    private String profissao;
    private String estadoCivil;


    public void setProfissao(String profissao)
    {
        this.profissao = profissao;
    }

    public String getProfissao()
    {
        return profissao;
    }

    public void setEstadoCivil(String estadoCivil)
    {
        this.estadoCivil = estadoCivil;
    }

    public String getEstadoCivil()
    {
        return estadoCivil;
    }
    
    @Override
    public String toString()
    {
        // TODO: Implement this method
        return getNome()+"\n  "+getContacto();
	}
    
    
    }
