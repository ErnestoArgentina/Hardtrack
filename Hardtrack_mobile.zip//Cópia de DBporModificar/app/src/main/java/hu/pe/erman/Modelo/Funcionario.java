package hu.pe.erman.Modelo;

public class Funcionario extends Pessoa
{
    
    public Funcionario(){};
    private String password;
    private Double salario;
    private String cargo;
    private String dadosBancarios;
    
   

    public void setDadosBancarios(String dadosBancarios)
    {
        this.dadosBancarios = dadosBancarios;
    }

    public String getDadosBancarios()
    {
        return dadosBancarios;
    }

    public void setCargo(String cargo)
    {
        this.cargo = cargo;
    }

    public String getCargo()
    {
        return cargo;
    }


    public void setPassword(String password)
    {
        this.password = password;
    }

    public String getPassword()
    {
        return password;
    }

    public void setSalario(Double salario)
    {
        this.salario = salario;
    }

    public Double getSalario()
    {
        return salario;
    }

    @Override
    public String toString()
    {
        // TODO: Implement this method
        return getNome() + "\n   "+getCargo();
    }
    
    
    
    
    
    
    
    
    
    }
