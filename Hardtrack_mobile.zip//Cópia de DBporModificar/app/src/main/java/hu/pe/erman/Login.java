package hu.pe.erman;
import android.app.*;
import android.content.*;
import android.database.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.os.*;
import android.support.annotation.*;
import android.view.*;
import android.widget.*;
import com.google.android.gms.tasks.*;
import com.google.firebase.auth.*;
import java.util.*;
import org.apache.http.util.*;
import hu.pe.erman.Coneccao.*;
import android.net.*;


public class Login extends Activity
{
	private FirebaseAuth auth;
	
	ArrayList<String> al;
	EditText email,pass;
	Db_Helper ddd;
	ListView lll;
	Cursor cr;
	Button login, btnovo;
	TextView erro,esqueceu;
	//AutoCompleteTextView mEmailView,mPasswordView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState)
    {
		///////ActionBar/////
		/////////////ActionBar/////
		ActionBar bar=getActionBar();
		//bar.setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000FF")));
		
		
		/////////////
		super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

		login=(Button)findViewById(R.id.login);
		btnovo=(Button)findViewById(R.id.nova);
		ddd=new Db_Helper(this);
		lll=(ListView)findViewById(R.id.lista);
		email=(EditText)findViewById(R.id.email);
		pass=(EditText)findViewById(R.id.pass);
		email.getBackground().setAlpha(50);
		esqueceu=(TextView)findViewById(R.id.esqueceuSenha);
		//erro=(TextView)findViewById(R.id.erro);
		//mEmailView=(AutoCompleteTextView)findViewById(R.id.email);
		//mPasswordView=(AutoCompleteTextView)findViewById(R.id.password);
		//populateAutoComplete();

		al=new ArrayList<>();
		cr=ddd.viewData();
		while(cr.moveToNext()){
			al.add(cr.getString(1));
		}
		
		
		login.setOnClickListener(new View.OnClickListener(){
			@Override
			public void onClick(View v){
				
//				for(int i=0;i<al.size();i++){
//					if(email.getText().toString().equalsIgnoreCase(al.get(i))){
//						Intent k=new Intent(Login.this,MainActivity.class);
//						startActivity(k);
//
//					}else
//						Toast.makeText(Login.this,"Codigo errado..",Toast.LENGTH_SHORT).show();
//				}
                if(!isNetworkAvailable())
                    alerta("Aviso", "Não há conecção à internet");
                    else{
	String txtemail=email.getText().toString().trim();
	String password=pass.getText().toString().trim();
	login(txtemail,password);	}
			}

			
		});
		
		
		
		
		btnovo.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){

		
						Intent k=new Intent(Login.this,Cadastro.class);
						startActivity(k);

				}
			});
		
			
		esqueceu.setOnClickListener(new View.OnClickListener(){
				@Override
				public void onClick(View v){


					Intent k=new Intent(Login.this,Recuperar.class);
					startActivity(k);

				}
			});
		
		

	}

	@Override
	protected void onStart()
	{
		// TODO: Implement this method
		super.onStart();
		auth=conexao.firebaseAuth();
	}
	
	
	
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/////////////./////////////////Autenyicacao//////////////
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
/*     private void attemptLoginOrRegister(boolean isNewUser) {
        if (mAuthTask != null) {
            return;
        }

        // Reset errors.
        mEmailView.setError(null);
        mPasswordView.setError(null);

        // Store values at the time of the login attempt.
        String email = mEmailView.getText().toString();
        String password = mPasswordView.getText().toString();

        boolean cancel = false;
        View focusView = null;

        // Check for a valid password, if the user entered one.
        if (!TextUtils.isEmpty(password) && !isPasswordValid(password)) {
            mPasswordView.setError(getString(R.string.error_invalid_password));
            focusView = mPasswordView;
            cancel = true;
        }

        // Check for a valid email address.
        if (TextUtils.isEmpty(email)) {
            mEmailView.setError(getString(R.string.error_field_required));
            focusView = mEmailView;
            cancel = true;
        } else if (!isEmailValid(email)) {
            mEmailView.setError(getString(R.string.error_invalid_email));
            focusView = mEmailView;
            cancel = true;
        }

        if (cancel) {
            // There was an error; don't attempt login and focus the first
            // form field with an error.
            focusView.requestFocus();
        } else {
            // Show a progress spinner, and kick off a background task to
            // perform the user login attempt.
            showProgress(true);
            if(isNewUser) {
                mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
						@Override
						public void onComplete(@NonNull Task<AuthResult> task) {
							showProgress(false);
							Toast.makeText(getApplicationContext(), "Usuário cadastrado com sucesso. Agora você pode se autenticar com suas credenciais!", Toast.LENGTH_LONG).show();
						}
					});
            }
            else {
                mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>() {
						@Override
						public void onComplete(@NonNull Task<AuthResult> task) {
							//showProgress(false);
							if(task.getResult().getUser() != null) {
								startActivity(new Intent(Login.this, MainActivity.class));
								finish();
							} else{
								Toast.makeText(getApplicationContext(), "Email e/ou senha incorretos.", Toast.LENGTH_LONG).show();
							}
						}
					});
            }
        }
    }               */
///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
	
	private void login(String txtemail, String password)
	{
		auth.signInWithEmailAndPassword(txtemail,password)
		
			.addOnCompleteListener(Login.this, new OnCompleteListener<AuthResult>(){

				@Override
				public void onComplete(Task<AuthResult> task)
				{
					// TODO: Implement this method
					if(task.isSuccessful()){
						finish();
						Intent i=new Intent(Login.this, MainActivity.class);
						startActivity(i);
					}else{
						alerta("erro","email ou senha errados");
					}
				}

				private void finish()
				{
					// TODO: Implement this method
					finish();
				}

				
			}
		);
	}
	
	
	private void alert(String p0)
	{
		Toast.makeText(getApplicationContext(), p0, Toast.LENGTH_LONG).show();
	}
	
	private void alerta(String titulo, String messagem)
	{
		AlertDialog.Builder ale=new AlertDialog.Builder(Login.this);
		ale.setCancelable(true);
		ale.setNegativeButton("OK",null);
		ale.setTitle(titulo);
		ale.setMessage(messagem);
		ale.setInverseBackgroundForced(true);
		ale.show();

	}
    
    
    
    
    
    
    /*@Override
     protected void onStart()
     {
     pb.setVisibility(View.INVISIBLE);
     // TODO: Implement this method
     super.onStart();
     if(!isNetworkAvailable())
     alerta("Aviso", "Não há conecção à internet");
     }
     */




    private boolean isNetworkAvailable()
    {
        ConnectivityManager cm=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo=cm.getActiveNetworkInfo();

        if(networkInfo !=null && networkInfo.isConnected()){
            return true;
        }
        return false;
    }
    
    
}
