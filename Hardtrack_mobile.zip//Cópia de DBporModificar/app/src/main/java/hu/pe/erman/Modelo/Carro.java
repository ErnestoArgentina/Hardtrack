package hu.pe.erman.Modelo;
import hu.pe.erman.*;




public class Carro {
	private String modelo;
    private String id;
    private String funcionarioID;
    private String ClienteID;
	//private String codigoModelo;
	private String marca;
	private String chassi;
	private String cor;
	private String combustivel;
	private String cilindrada;
	private String caixa;
	//private String numero_referencia;
	private String estadoCompra;
	private String estadoDeletado;
	private Double preco;
	private String anoFabrico;
	private String volante;
	//private String assentos;
	//private String portas;
    private String usuarioAuthID;
	//private String clienteCompra;
	private String tipoCarro;
	private String dataRegisto;
	private String dataVenda;
	private String serie;
	private String imageUrl;
	
	public Carro() {
	
	}

    public void setClienteID(String clienteID)
    {
        ClienteID = clienteID;
    }

    public String getClienteID()
    {
        return ClienteID;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    public void setFuncionarioID(String funcionarioID)
    {
        this.funcionarioID = funcionarioID;
    }

    public String getFuncionarioID()
    {
        return funcionarioID;
    }

	public void setModelo(String modelo)
	{
		this.modelo = modelo;
	}

	public String getModelo()
	{
		return modelo;
	}

	public void setMarca(String marca)
	{
		this.marca = marca;
	}

	public String getMarca()
	{
		return marca;
	}

	public void setChassi(String chassi)
	{
		this.chassi = chassi;
	}

	public String getChassi()
	{
		return chassi;
	}

	public void setCor(String cor)
	{
		this.cor = cor;
	}

	public String getCor()
	{
		return cor;
	}

	public void setCombustivel(String combustivel)
	{
		this.combustivel = combustivel;
	}

	public String getCombustivel()
	{
		return combustivel;
	}

	public void setCilindrada(String cilindrada)
	{
		this.cilindrada = cilindrada;
	}

	public String getCilindrada()
	{
		return cilindrada;
	}

	public void setCaixa(String caixa)
	{
		this.caixa = caixa;
	}

	public String getCaixa()
	{
		return caixa;
	}

	public void setEstadoCompra(String estadoCompra)
	{
		this.estadoCompra = estadoCompra;
	}

	public String getEstadoCompra()
	{
		return estadoCompra;
	}

	public void setEstadoDeletado(String estadoDeletado)
	{
		this.estadoDeletado = estadoDeletado;
	}

	public String getEstadoDeletado()
	{
		return estadoDeletado;
	}

	public void setPreco(Double preco)
	{
		this.preco = preco;
	}

	public Double getPreco()
	{
		return preco;
	}

	public void setAnoFabrico(String anoFabrico)
	{
		this.anoFabrico = anoFabrico;
	}

	public String getAnoFabrico()
	{
		return anoFabrico;
	}

	public void setVolante(String volante)
	{
		this.volante = volante;
	}

	public String getVolante()
	{
		return volante;
	}

	public void setUsuarioAuthID(String usuarioAuthID)
	{
		this.usuarioAuthID = usuarioAuthID;
	}

	public String getUsuarioAuthID()
	{
		return usuarioAuthID;
	}

	public void setTipoCarro(String tipoCarro)
	{
		this.tipoCarro = tipoCarro;
	}

	public String getTipoCarro()
	{
		return tipoCarro;
	}

	public void setDataRegisto(String dataRegisto)
	{
		this.dataRegisto = dataRegisto;
	}

	public String getDataRegisto()
	{
		return dataRegisto;
	}

	public void setDataVenda(String dataVenda)
	{
		this.dataVenda = dataVenda;
	}

	public String getDataVenda()
	{
		return dataVenda;
	}

	public void setSerie(String serie)
	{
		this.serie = serie;
	}

	public String getSerie()
	{
		return serie;
	}

	public void setImageUrl(String imageUrl)
	{
		this.imageUrl = imageUrl;
	}

	public String getImageUrl()
	{
		return imageUrl;
	}
    
    
    

    @Override
    public String toString()
    {
        // TODO: Implement this method
        return marca+"\n   🚗: "+modelo+"\n   🕒: "+anoFabrico+"\n   "+"💰: "+preco;
    }

	

	public void delete(){
        this.estadoDeletado="off";
    }


	
	
	
}
