package hu.pe.erman;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;

public class Db_Helper extends SQLiteOpenHelper
{

	public Db_Helper(Context ccc){
	super(ccc,"friends.db",null,1);
	}
	@Override
	public void onCreate(SQLiteDatabase p1)
	{
		// TODO: Implement this method
		p1.execSQL("CREATE TABLE friendss(ID INTEGER PRIMARY KEY AUTOINCREMENT, NAME TEXT)");
	}

	@Override
	public void onUpgrade(SQLiteDatabase p1, int p2, int p3)
	{
		// TODO: Implement this method
		p1.execSQL("DROP TABLE IF EXISTS friendss");
		onCreate(p1);
	}
	public boolean insertData(String name){
		
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues ccc=new ContentValues();
		ccc.put("NAME", name);
		long result=db.insert("friendss",null,ccc);
		
		if(result== -1)
			return false;
			else

		
		return true;
	}
	
	public Cursor viewData(){
		SQLiteDatabase db =this.getWritableDatabase();
		Cursor res=db.rawQuery("SELECT*FROM friendss",null);
		return res;
	}
	
	public boolean upDateData(String id, String name){
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues ccc=new ContentValues();
		ccc.put("NAME", name);
		
		db.update("friendss",ccc,"ID=?",new String[] {id});
		return true;
	}
	
	public Integer deleteDatay(String id){
		SQLiteDatabase db =this.getWritableDatabase();
		return db.delete("friendss","ID=?",new String[] {id});
	}
	public Integer deleteData(String id){
		SQLiteDatabase db =this.getWritableDatabase();
		return db.delete("friendss","NAME=?",new String[] {id});
	}
}