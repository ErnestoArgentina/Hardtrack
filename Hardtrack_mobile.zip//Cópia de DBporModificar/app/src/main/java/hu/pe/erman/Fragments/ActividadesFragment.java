package hu.pe.erman.Fragments;
import android.app.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.google.android.gms.ads.*;
import hu.pe.erman.*;
import hu.pe.erman.R;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DatabaseReference;
import hu.pe.erman.Modelo.*;
import java.util.List;
import java.util.ArrayList;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.FirebaseApp;
import hu.pe.erman.Coneccao.*;

public class ActividadesFragment
extends Fragment
{
    
    ListView lista;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private List<Actividade> listActividade=new ArrayList<Actividade>();
    private ArrayAdapter<Actividade> arrayAdapterActividade;

    private FirebaseAuth mAuth;

    private FirebaseUser user;
    
    
    
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
    {
      
        View view=inflater.inflate(R.layout.fragment_atividades, container, false);

        //ANUNCIOS
      //  MobileAds.initialize(getActivity(), "ca-app-pub-9016085290328620~1226986182");
       // AdView adView=(AdView)view.findViewById(R.id.adViewHome);
    //    AdRequest adRequest=new AdRequest.Builder().build();
      //  adView.loadAd(adRequest);
        inicializarFirebase();
      lista=(ListView)view.findViewById(R.id.atividadesListView);
      
        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();
      
eventoDatabase();

     


        return view;

    }
    
    
    
    
    
    
    
    private void eventoDatabase()
    {
        //Query query=databaseReference.child("Actividades").child("usuarioAuthID").equalTo(mAuth.getCurrentUser().getUid().toString());

        databaseReference.child("Actividade").addValueEventListener(new ValueEventListener(){

                @Override
                public void onDataChange(DataSnapshot dataSnapshot)
                {
                    listActividade.clear();
                    for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
                    {
                        Actividade act=objSnapshot.getValue(Actividade.class);
                        if (act.getUsuarioAuthID().equalsIgnoreCase(user.getUid() + ""))
                            listActividade.add(act);

                    }
                    arrayAdapterActividade = new ArrayAdapter<Actividade>(getActivity(), R.layout.list_item, listActividade);

                    lista.setAdapter(arrayAdapterActividade);

                }

                @Override
                public void onCancelled(DatabaseError p1)
                {
                    // TODO: Implement this method
                    alerta(p1.toString());
                }
            });
    }
    
    
    
    
    
    
    private void inicializarFirebase()
    {
        // alerta(" "+InitFirebase.jaIniciou);
        // TODO: Implement this method
        FirebaseApp.initializeApp(getActivity());
        firebaseDatabase = FirebaseDatabase.getInstance();
        if (InitFirebase.jaIniciou == 0)
            firebaseDatabase.setPersistenceEnabled(true);
        databaseReference = firebaseDatabase.getReference();
        InitFirebase.jaIniciou++;

    }
    
    
    
    

    private void alerta(String texto)
    {
        // TODO: Implement this method
        AlertDialog.Builder ale=new AlertDialog.Builder(getActivity());
        ale.setCancelable(true);
        ale.setIcon(R.drawable.ic_alerta_preto);
        ale.setTitle("Alerta");
        ale.setMessage(texto);
        ale.show();
    }



}
