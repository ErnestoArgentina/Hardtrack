package hu.pe.erman;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import hu.pe.erman.Modelo.*;

public class Db_Funcionario_Logado extends SQLiteOpenHelper
{

	public Db_Funcionario_Logado(Context ccc){
	super(ccc,"Db_Funcionarios.db",null,1);
	}
	@Override
	public void onCreate(SQLiteDatabase p1)
	{
		// TODO: Implement this method
		p1.execSQL("CREATE TABLE Funcionarioss(ID TEXT, NAME TEXT,BI TEXT,TELEFONE TEXT,EMAIL TEXT,MORADA TEXT)");
	}

    
    
    
    
    
    
	@Override
	public void onUpgrade(SQLiteDatabase p1, int p2, int p3)
	{
		// TODO: Implement this method
		p1.execSQL("DROP TABLE IF EXISTS Funcionarioss");
		onCreate(p1);
	}
    
    
    
    
    
    
	public boolean insertData(Funcionario funcionario){
		
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues ccc=new ContentValues();
		String name=funcionario.getNome();
		String Bi=funcionario.getBi();
		String telefone=funcionario.getContacto();
		String email=funcionario.getEmail();
		String morada=funcionario.getMorada();
        ccc.put("ID", funcionario.getId());
		ccc.put("NAME", name);
		ccc.put("BI", Bi);
		ccc.put("TELEFONE", telefone);
		ccc.put("EMAIL", email);
		ccc.put("Morada",morada);
		long result=db.insert("Funcionarioss",null,ccc);
		
		if(result== -1)
			return false;
			else

		
		return true;
	}
	
    
    
    
    
    
    
	public Cursor viewData(){
		SQLiteDatabase db =this.getWritableDatabase();
		Cursor res=db.rawQuery("SELECT*FROM Funcionarioss",null);
		return res;
	}
	
    
    
    
    
    
    
	public boolean upDateData(String id, String name){
		SQLiteDatabase db=this.getWritableDatabase();
		ContentValues ccc=new ContentValues();
		ccc.put("NAME", name);
		
		db.update("Funcionarioss",ccc,"ID=?",new String[] {id});
		return true;
	}
	
    
    
    
    
    
    
	public Integer deleteData(String id){
		SQLiteDatabase db =this.getWritableDatabase();
		return db.delete("Funcionarioss","ID=?",new String[] {id});
	}
	
    
    
    
    
    
    
}
