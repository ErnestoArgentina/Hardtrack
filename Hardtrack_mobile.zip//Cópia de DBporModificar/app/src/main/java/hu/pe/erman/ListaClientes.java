package hu.pe.erman;

import android.content.*;
import android.graphics.drawable.*;
import android.os.*;
import android.support.v7.app.ActionBarActivity;
import android.view.*;
import android.widget.*;
import com.google.firebase.database.FirebaseDatabase;
import hu.pe.erman.Coneccao.*;
import java.util.*;
import android.support.design.widget.FloatingActionButton;
import android.graphics.Color;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import android.support.v7.app.AlertDialog;
import com.google.firebase.FirebaseApp;
import hu.pe.erman.Modelo.*;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;
import android.view.View.*;
import java.text.*;


public class ListaClientes extends ActionBarActivity implements OnClickListener
{
    ListView lll;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    private List<Cliente> listCliente=new ArrayList<Cliente>();
    private ArrayAdapter<Cliente> arrayAdapterCliente;
    EditText nome,email,morada,telefone,bi;
    EditText biArquivo,biDataEmissao,BiDataValidade,profissao;
    private FirebaseAuth mAuth;
    private Cliente ClienteSelecionado;
    private Actividade act;
    private FloatingActionButton fab;

    private FirebaseUser user;
    private Button btDataEmissao,btDataValidade;
    private String sexo="null";
    private String estadoCivil="null";
    private DatePicker datePicker;
    private Date dataActual =new Date();
    private SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
    private String data;
    
    
    
    
    
    
    
    
    

    @Override
    public void onClick(View view)
    {
        // TODO: Implement this method
        boolean checked=((RadioButton) view).isChecked();

        switch (view.getId())
        {
                /////////Sexo
            case R.id.rbMasculinoCliente:
                if (checked) 
                    sexo = "Masculino";
                break;
            case R.id.rbFemininoCliente:
                if (checked)
                    sexo = "Feminino";
                break;
            case R.id.rbCasadoCliente:
                if (checked) 
                    estadoCivil = "Casado";
                break;
            case R.id.rbSolteiroCliente:
                if (checked)
                    estadoCivil = "Solteiro";
                break;
        }
    }






	




	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return super.onCreateOptionsMenu(menu);
	}



	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int id=item.getItemId();

		/*if(id==R.id.action_RegistarCliente){
         Intent i=new Intent(ListaClientes.this,RegistarCliente.class);
         startActivity(i);
         }*/

		if (id == R.id.action_exit)
        {
			finish();
		}
		if (id == R.id.action_SairDaConta)
        {
	        mAuth.getInstance().signOut();
			Intent i=new Intent(ListaClientes.this, Login.class);
			startActivity(i);
		}
		return super.onOptionsItemSelected(item);
	}



	@Override
	protected void onCreate(Bundle savedInstanceState)
    {

		super.onCreate(savedInstanceState);
        setContentView(R.layout.lista_clientes);
		inicializarvariaveis();
		inicializarFirebase();
        InitFirebase.jaIniciou += 1;
        accao_listview();

        mAuth = FirebaseAuth.getInstance();
        user = mAuth.getCurrentUser();



		TabHost th=(TabHost)findViewById(R.id.tthhClientes);
		th.setup();
		th.getBottom();

		TabHost.TabSpec sp=th.newTabSpec("");
		sp.setContent(R.id.registoCliente);
		sp.setIndicator("📝Registar");
		th.setBackground(new ColorDrawable(Color.parseColor("#007fff")));
		th.addTab(sp);

		sp = th.newTabSpec("");
		sp.setContent(R.id.ListViewCliente);
		sp.setIndicator("📃Listar");
		th.addTab(sp);
        



		ArrayAdapter<CharSequence> spSexoAdapter=ArrayAdapter.createFromResource(this,
																				 R.array.sexoArray, android.R.layout.simple_spinner_item);

		//spSexoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		//spSexo.setAdapter(spSexoAdapter);





		fab.setOnClickListener(new View.OnClickListener(){

				@Override
				public void onClick(View p1)
                {
					Cliente cl=new Cliente();
					cl.setBi(bi.getText().toString());
					cl.setNome(nome.getText().toString());
					cl.setEmail(email.getText().toString());
					cl.setMorada(morada.getText().toString());
					cl.setContacto((telefone.getText().toString()));
                    cl.setUsuarioAuthID(user.getUid() + "");
                    cl.setId(UUID.randomUUID().toString());
                    cl.setBiArquivoIdentificacao(biArquivo.getText().toString().trim());
                    cl.setBiDataEmissao(biDataEmissao.getText().toString().trim());
                    cl.setBiDataValidade(BiDataValidade.getText().toString().trim());
                    cl.setProfissao(profissao.getText().toString().trim());
                    cl.setSexo(sexo);
                    cl.setEstadoCivil(estadoCivil);
                    cl.setEstadoDeletado("on");


					if (bi.getText().toString().equals("") || nome.getText().toString().equals("") || telefone.getText().toString().equals("") || morada.getText().toString().trim().equals(""))
                    {
						AlertDialog.Builder ale=new AlertDialog.Builder(ListaClientes.this);
						ale.setCancelable(true);
						ale.setIcon(R.drawable.ic_alerta_preto);
						ale.setTitle("ERRO");
						ale.setMessage("Preencha todos os campos");
						ale.show();
					}
                    else
                    {
                        if (email.getText().toString().trim().contains("@") && email.getText().toString().trim().contains("."))
                        {
                            if (nome.getText().toString().trim().contains(" "))
                            {
                                databaseReference.child("Cliente").child(cl.getId()).setValue(cl);
                                alerta("Gravado com Sucesso");   
                                registarActividade("Adicionou ",cl.getId(),cl.getNome());
                                limparCampos();
                            }
                            else alerta("Introduza um nome completo");
                        }
                        else alerta("Introduza um Email Valido");
					}
				}});


		eventoDatabase();
        btDataEmissao.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
             
                 alertDatePicker(biDataEmissao);
            }
        });
        btDataValidade.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view){
                  
                    alertDatePicker(BiDataValidade);
                }
            });
	}

	private void eventoDatabase()
	{
        //Query query=databaseReference.child("Clientes").child("usuarioAuthID").equalTo(mAuth.getCurrentUser().getUid().toString());

		databaseReference.child("Cliente").addValueEventListener(new ValueEventListener(){

				@Override
				public void onDataChange(DataSnapshot dataSnapshot)
				{
					listCliente.clear();
					for (DataSnapshot objSnapshot:dataSnapshot.getChildren())
                    {
						Cliente c=objSnapshot.getValue(Cliente.class);
                        if (c.getUsuarioAuthID().equalsIgnoreCase(user.getUid() + "") && c.getEstadoDeletado().equalsIgnoreCase("on"))
                            listCliente.add(c);

					}
					arrayAdapterCliente = new ArrayAdapter<Cliente>(ListaClientes.this, R.layout.list_item, listCliente);

                    lll.setAdapter(arrayAdapterCliente);

				}

				@Override
				public void onCancelled(DatabaseError p1)
				{
					// TODO: Implement this method
                    alerta(p1.toString());
				}
			});
	}





	private void inicializarvariaveis()
	{
		lll = (ListView)findViewById(R.id.lista);
		fab = (FloatingActionButton) findViewById(R.id.fabSaveCliente);
		nome = (EditText) findViewById(R.id.nomeCliente);
		bi = (EditText) findViewById(R.id.biCliente);
		telefone = (EditText) findViewById(R.id.telefoneCliente);
		morada = (EditText) findViewById(R.id.moradaCliente);
		email = (EditText) findViewById(R.id.emailCliente);
        biArquivo = (EditText) findViewById(R.id.biArquivoCliente);
        biDataEmissao = (EditText) findViewById(R.id.biDataEmissaoEditTextCliente);
        BiDataValidade = (EditText) findViewById(R.id.biDataValidadeEditTextCliente);
        btDataValidade = (Button) findViewById(R.id.biDataValidadeCliente);
        btDataEmissao = (Button) findViewById(R.id.biDataEmissaoCliente);
        profissao = (EditText) findViewById(R.id.profissaoCliente);
		//spSexo=(Spinner)findViewById(R.id.lista_ClienteSpinner);
	}







	private void inicializarFirebase()
	{
        // alerta(" "+InitFirebase.jaIniciou);
		// TODO: Implement this method
		FirebaseApp.initializeApp(ListaClientes.this);
		firebaseDatabase = FirebaseDatabase.getInstance();
        if (InitFirebase.jaIniciou == 0)
            firebaseDatabase.setPersistenceEnabled(true);
		databaseReference = firebaseDatabase.getReference();

    }





	private void limparCampos()
	{
		bi.setText("");
		nome.setText("");
		email.setText("");
		morada.setText("");
		telefone.setText("");
        profissao.setText("");
        biDataEmissao.setText("");
        BiDataValidade.setText("");
        biArquivo.setText("");
	}





    private void alerta(String p0)
    {
        AlertDialog.Builder ale=new AlertDialog.Builder(ListaClientes.this);
        ale.setCancelable(true);
        ale.setIcon(R.drawable.ic_alerta_branco);
        ale.setTitle("Alert");
        ale.setMessage(p0);
        ale.show();
    }





    public void alertEditCliente()
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(ListaClientes.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_edit_clientes, null);
        final EditText mEmail=(EditText)mView.findViewById(R.id.DialogEmailCliente);
        final EditText mBI=(EditText)mView.findViewById(R.id.DialogBICliente);
        final EditText mNome=(EditText)mView.findViewById(R.id.DialogNomeCliente);
        final EditText mTelefone=(EditText)mView.findViewById(R.id.DialogTelefoneCliente);
        final EditText mMorada=(EditText)mView.findViewById(R.id.DialogMoradaCliente);
        mEmail.setText(ClienteSelecionado.getEmail());
        mBI.setText(ClienteSelecionado.getBi());
        mNome.setText(ClienteSelecionado.getNome());
        mTelefone.setText(ClienteSelecionado.getContacto());
        mMorada.setText(ClienteSelecionado.getMorada());

        Button DialogButtonEliminar=(Button) mView.findViewById(R.id.DialogButtonEliminar);

        DialogButtonEliminar.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    ClienteSelecionado.delete();
                    databaseReference.child("Cliente").child(ClienteSelecionado.getId()).setValue(ClienteSelecionado);
                    alerta("Eliminado com sucesso");
                    registarActividade("Eliminou os dados do cliente ",ClienteSelecionado.getId(),ClienteSelecionado.getNome());


                }
            });
        Button DialogButtonEditar=(Button) mView.findViewById(R.id.DialogButtonSalvar);

        DialogButtonEditar.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {
                    ClienteSelecionado.setNome(mNome.getText().toString().trim());
                    ClienteSelecionado.setBi(mBI.getText().toString().trim());
                    ClienteSelecionado.setContacto(mTelefone.getText().toString().trim());
                    ClienteSelecionado.setEmail(mEmail.getText().toString().trim());
                    ClienteSelecionado.setMorada(mMorada.getText().toString().trim());
                    databaseReference.child("Cliente").child(ClienteSelecionado.getId()).setValue(ClienteSelecionado);
                    alerta("Editado com sucesso");
                    registarActividade("Actualizou os dados do cliente ",ClienteSelecionado.getId(),ClienteSelecionado.getNome());

                }
            });
        mBuilder.setView(mView);
        AlertDialog dialog=mBuilder.create();
        dialog.show();

    }







    void accao_listview()
    {
        lll.setOnItemClickListener(new AdapterView.OnItemClickListener(){

                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id)
                {
                    // TODO: Implement this method
                    ClienteSelecionado = (Cliente)parent.getItemAtPosition(position);
                    alertEditCliente();
                }
            });
    }












    public void alertDatePicker(final EditText e)
    {
        // TODO: Implement this method
        AlertDialog.Builder mBuilder= new AlertDialog.Builder(ListaClientes.this);
        View mView=getLayoutInflater().inflate(R.layout.dialog_date_picker, null);
         


        FloatingActionButton DialogDatePickerButtonOk=(FloatingActionButton) mView.findViewById(R.id.datePickerButton);
        datePicker = (DatePicker)mView.findViewById(R.id.datePicker);

        DialogDatePickerButtonOk.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View view)
                {


                   //dataObtida= minhaData();
                   // setarData(dataObtida);
                    e.setText(minhaData());

                }

                private void setarData(String dataObtida)
                {
                    // TODO: Implement this method
                    e.setText(dataObtida);
                }
                private String minhaData()
                {
                    StringBuilder myCat=new StringBuilder();

                    myCat.append(datePicker.getDayOfMonth() + "/");
                    myCat.append((datePicker.getMonth() + 1) + "/");
                    myCat.append(datePicker.getYear());

                    return myCat.toString();
                }
                
                
            });

        mBuilder.setView(mView);
       AlertDialog dialog=mBuilder.create();
        dialog.show();
         //FecharAlert(dialog);
            
        
         
    }
    
    
    
    
    
    

    private void FecharAlert(AlertDialog dialog)
    {
        // TODO: Implement this method
        dialog.dismiss();
    }






public void registarActividade(String actividade, String id, String nomeCliente){
   data=sdf.format(dataActual);
   act=new Actividade();
    act.setNomeActividade(actividade+" "+nomeCliente+" na lista de clientes");
    act.setId(UUID.randomUUID().toString());
    act.setVisto(false);
    act.setIdActividadeFeita(id);
    act.setDataActividade(data);
    act.setUsuarioAuthID(user.getUid().toString());
    databaseReference.child("Actividade").child(act.getId()).setValue(act);
}







}
